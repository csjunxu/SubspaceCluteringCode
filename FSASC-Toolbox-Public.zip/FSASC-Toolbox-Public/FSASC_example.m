% A simple example demonstrating FSASC

% For details in the algorithm please refer to 
% M.C. Tsakiris and R. Vidal, "Filtrated Spectral Algebraic
% Subspace Clustering", International Conference on Computer 
% Vision, 2015. 

% Copyright @ Manolis C. Tsakiris, 2016

clear all
close all

%% experiment parameters
D = 9;
n = 3;
Ns = 200;
N = Ns * ones(1,n);
noise = 0.01;
dimensions = [6 7 8];

%% FSASC parameters
n_v = n;
filtr_mcl = 10;
gamma = .1;
minimum_attenuation = 10^(-5);

%% create subspaces
span = cell(1,n);
normals = cell(1,n);
for i = 1 : n
    V = randn(D);
    [Q, R] = qr(V);
    span{i} = Q(:,1:dimensions(i));
    normals{i} = Q(:,dimensions(i)+1:D);
end

%% sample the subspaces
Y_clean = cell(n);
for i = 1 : n
    Y_clean{i} = span{i}*randn(dimensions(i),N(i));
end

%% add noise
Y = [];
for i = 1 : n
    Y = [Y Y_clean{i}+noise*normals{i}*randn(D-dimensions(i),N(i))];
end

%% normalize data
temp = sqrt(sum(Y .* Y,1));
Y = Y ./ (ones(D,1) * temp);

%% ground truth labels
s = [];
for i = 1 : n
    s = [s i * ones(1,N(i))];
end

%% obtain FSASC affinity
affinity = FSASC_affinity(Y,n,n_v,gamma,filtr_mcl,minimum_attenuation);

%% clustering
groups = SpectralClustering(affinity,n);
missrate = Missclassification(groups,s)



