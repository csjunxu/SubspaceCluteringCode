function [AFFINITY, eigengap, local_dimensions, admissible_attenuation] = FSASC_affinity(X,n,n_v,gamma,filtr_mcl,minimum_attenuation)

% DESCRIPTION
% Computation of a pairwise affinity based on filtrations.
% INPUT
% X                      : data points arranged in the columns of X
% n                      : number of subspaces (or estimate; better use an upper bound)
% n_v                    : degree of vanishing polynomials
% gamma                  : a technical parameter pertaining to the computation
%                          of the admissible_attenuation of the reference points.
% filtr_mcl              : minimum number of connections to each reference point
% minimum_attenuation    : minimum attenuation of the norm of each
%                          reference point across its filtration
% OUTPUT
% AFFINITY               : the symmetrized pairwise affinity matrix
% eigengap               : the eigengap of the affinity matrix with respect
%                          to n connected components
% local_dimensions       : the j-th entry is the estimate of the dimension
%                          of the subspace to which the j-th column of X belongs
% admissible_attenuation : the admissible attenuation of the norm of each
%                          reference point
% Copyright @ Manolis C. Tsakiris, 2016

%% dimensions
[D N] = size(X);

%% compute a vanishing polynomial
[Ln,powers] = veronese(X,n_v);
Ln = Ln.';
[U,S,V] = svd(Ln);
Mn = nchoosek(n_v+D-1,n_v);
c = V(:,Mn);
powers = exponent(n_v,D);

%% compute admissible attenuation
initial_attenuations = zeros(1,N);
for i = 1 : N
    [Dpn,normDpn] = cnormalize(derivative(c,powers,X(:,i)));
    initial_attenuations(i) = abs(Dpn' * X(:,i));
end
admissible_attenuation = gamma*mean(initial_attenuations);
admissible_attenuation = max(admissible_attenuation,minimum_attenuation);


%% construct affinity
affinity = zeros(N);
local_dimensions = zeros(1,N);
for j = 1 : N
    [filtration_indices, filtration_norms, local_dimension]  = FSASC_Filtration(X(:,j),X,c,n_v,admissible_attenuation,filtr_mcl);    
    affinity(j,filtration_indices) = filtration_norms;
    local_dimensions(j) = local_dimension;
end

%% affinity PP
AFFINITY = affinity+affinity';
%% compute the eigengap
D = diag(sum(AFFINITY))+ 10^(-6)*eye(N);
D_sqrt = sqrt(D);
D_sqrt_inv = diag(1 ./ diag(D_sqrt));
L = D - AFFINITY;
L = D_sqrt_inv * L * D_sqrt_inv;
lambda_min = eigs(L,n+1,'SM');
lambda_min = sort(lambda_min,'descend');
eigengap = (lambda_min(1) - lambda_min(2));

end