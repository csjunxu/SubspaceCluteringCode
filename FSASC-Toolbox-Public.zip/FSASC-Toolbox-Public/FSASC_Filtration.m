function [filtration_indices, filtration_norms, local_dimension] = FSASC_Filtration(ref_point,X,c,n_v,admissible_attenuation,filtr_mcl)

% DESCRIPTION
% Computation of a filtration for a given reference point.
% INPUT
% ref_point              : the reference point
% X                      : the data points arranged in the columns of X.
% c                      : the coefficients of an initial vanishing polynomial
% n_v                    : the degree of the initial vanishing polynomial
% admissible_attenuation : the tolerance on the drop of the norm of the
%                          projected point across the filtration (in theory the drop is zero)
% filtr_mcl              : the minimum number of points to be connected to
%                          the reference point
% OUTPUT
% filtration_indices     : the indices of points connected to the reference point
% filtration_norms       : the norms at the end of the filtration of the points connected 
%                          to the reference point
% local_dimension        : estimate for the subspace dimension + 1

% Copyright @ Manolis C. Tsakiris, 2016

[D, N] = size(X);
Y = X;
local_dimension = D;
linear_indices = 1 : 1 : N;
filtration_flag = 1;
filtration_indices = linear_indices;
intermediate_indices = linear_indices;
norms_old = ones(1,N);

while local_dimension >= 2 && filtration_flag==1
    % do a hyperplane projection
    [Y, ref_point_projected, norms_new] = FSASC_Hyperplane_Projection(ref_point,Y,c,n_v);
    
    % check the relative attenuation of the reference point
    current_attenuation = (norm(ref_point)- norm(ref_point_projected))/(norm(ref_point)+10^(-6));                      
    if current_attenuation > admissible_attenuation
        filtration_flag = 0;
    else        
        % find points with small attenuation        
        CRA = (norms_old - norms_new) ./ norms_old;
        intermediate_indices = find(CRA <= admissible_attenuation);        
        if length(intermediate_indices) < filtr_mcl
            filtration_flag = 0;
        else
            % primary updates          
            norms_old = norms_new(intermediate_indices);
            filtration_indices = filtration_indices(intermediate_indices);            
            local_dimension = local_dimension - 1;
            
            % check if there are enough points for veronese embedding
            if length(intermediate_indices) < nchoosek(n_v+local_dimension-1,n_v)
                filtration_flag = 0;
            else
                % secondary updates                
                ref_point = ref_point_projected;
                Y = Y(:,intermediate_indices);
                
                % compute a vanishing polynomial
                [Ln,powers] = veronese(Y,n_v);
                Ln = Ln.';                
                [U,S,V] = svd(Ln);
                Mn = nchoosek(n_v+local_dimension-1,n_v);
                c =  V(:,Mn);                
            end
        end
    end
end

 %% filter further the selected indices
if local_dimension == D       
    filtration_norms = norms_new;
else        
    filtration_norms = norms_old;
end


