% Copyright @ Manolis C. Tsakiris, 2015

function miss = Missclassification(Segmentation,RefSegmentation)

ngroups = max(RefSegmentation);

if isrow(Segmentation) == 0
    Segmentation = Segmentation';
end
if isrow(RefSegmentation) == 0
    RefSegmentation = RefSegmentation';
end

Permutations = perms(1:ngroups);
miss = zeros(size(Permutations,1),1);
for j=1:size(Permutations,1)
    miss(j) = sum(Segmentation~=Permutations(j,RefSegmentation));
end

miss = min(miss)/length(RefSegmentation);

