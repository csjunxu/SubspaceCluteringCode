function [Y_projected ref_point_projected norms] = FSASC_Hyperplane_Projection(ref_point,Y,c,n_v)

% DESCRIPTION
% Given a polynomial, a projection is performed onto the
% hyperplane with normal vector equal to the gradient of that
% polynomial at some reference point.
% INPUT
% ref_point           : the reference point
% Y                   : the set of all points (arranged in the columns of Y)
% c                   : the coefficients of the vanishing polynomial
% n_v                 : the degree of the vanishing polynomial
% OUTPUT   
% Y_projected         : the projected data points
% ref_point_projected : the projected reference point
% norms               : the norms of the data points after projection

% Copyright @ Manolis C. Tsakiris, 2016


[K,N] = size(Y);

%% compute normal from polynomial
powers = exponent(n_v,K);
[Dpn,normDpn] = cnormalize(derivative(c,powers,ref_point/norm(ref_point)));

%% find a basis for the hyperplane Dpn
I = eye(K);
E = [Dpn I];
[Q R] = qr(E);
H = Q(:,2:K);

%% project the data onto the hyperplane Dpn
P = (H'*H+10^(-6)*eye(K-1)) \ H';
Y_projected = P*Y;
ref_point_projected = P* ref_point;
norms = sqrt(sum(Y_projected .* Y_projected,1));


end